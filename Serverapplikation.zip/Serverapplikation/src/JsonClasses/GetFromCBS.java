package JsonClasses;

public class GetFromCBS {
	
	private  final long serialVersionUID = 1L;
	private String overallID = "importCalendar";
	
	public String getOverallID() {
		return overallID;
	}
	public void setOverallID(String overallID) {
		this.overallID = overallID;

	}
}
