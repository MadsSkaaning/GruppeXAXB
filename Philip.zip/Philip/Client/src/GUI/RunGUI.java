package GUI;

public class RunGUI {

	public static void main(String[] args) {
		
		
		GUILogic logic = new GUILogic();
		logic.run();
		
	}
}

