package logic;

import GUI.GUILogic;


public class Main {

	public static void main(String[] args) {
		
		GUILogic gui = new GUILogic();
		
		gui.run();
		
		
		
		
		

	}

}