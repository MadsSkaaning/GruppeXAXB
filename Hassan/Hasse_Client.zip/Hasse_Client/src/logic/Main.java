package logic;

import gui.GuiLogic;

public class Main {

	public static void main(String[] args) {
		
		GuiLogic gui = new GuiLogic();
		
		gui.run();
		
		
		
		
		

	}

}
